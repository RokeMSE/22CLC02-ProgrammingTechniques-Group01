#pragma once

#define uint unsigned int
#define ushort unsigned short
struct DATE {
    ushort day, month;
    uint year;
};
#pragma once

#define uint unsigned int
#define ushort unsigned short

struct CLASS {
    uint K;
    Program program;
    ushort No;
    // 22CLC2: K = 22, program = CLC, No = 2
};
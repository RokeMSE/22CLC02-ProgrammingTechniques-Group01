#pragma once

enum Program { APCS, CLC, VP };
enum WeekDay { MON, TUE, WED, THU, FRI, SAT, SUN };
#pragma once
#include <msclr/marshal_cppstd.h>
#include "Structs.h"
#include "helperFunctions.h"
#include "GlobalVariables.h"
#include "import.h"
#include "export.h"